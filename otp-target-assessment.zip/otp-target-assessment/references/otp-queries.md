# OTP GraphQL API v4 查询参考（已实测验证）

端点：`https://api.platform.opentargets.org/api/v4/graphql`（POST，Content-Type: application/json，body 为 `{"query": "...", "variables": {...}}`）。
MCP 客户端（opentargets 连接器）存在全局限流，被限流时（"Rate limit exceeded for client: global"）**改用直连 HTTP POST 或本地脚本**（`scripts/otp_query.py` 已内置）。

## 0. 参数陷阱（踩坑记录，必须遵守）

- `search` 的 `entityNames` 参数接受**字符串数组** `["target"]`，不是枚举裸值（`[target]` 会报 "Expected type 'String!'"）。
- `target.associatedDiseases` / `disease.associatedTargets` 的疾病/靶标过滤参数名在 introspection 中**字面叫 `Bs`**（`[String!]`），不是 `efoIds`。传 `Bs: ["MONDO_..."]`。
- `meta.dataVersion` 是对象，必须带子选择 `{ month year iteration }`，否则报 "must have a sub selection"；`meta.apiVersion` 同理需要子选择（字段名以 introspection 为准）。
- 同一字段在 API 不同版本间字段名可能变动（如 `CredibleSet.variantId` 已改 `variant { id }`）。**动手前先跑一次 introspection**（见 §8）核对字段名，可避免反复试错。
- 默认分页：`associatedTargets`/`evidences` 等默认只返回一页（约 25 条），需要全部时传 `page: {index: 0, size: 100}`（Pagination 输入类型字段以 introspection 为准）。

## 1. 实体解析（search）

```graphql
query { a: search(queryString: "MRGPRX2", entityNames: ["target"]) { total hits { id entity name } } }
query { b: search(queryString: "chronic spontaneous urticaria", entityNames: ["disease"]) { total hits { id entity name } } }
```
- 靶标 → Ensembl ID（ENSG...）；疾病 → EFO_ / MONDO_ ID。
- CSU/慢性特发性荨麻疹 → MONDO_0044212；注意同义词节点（如 chronic idiopathic urticaria / chronic urticaria）。

## 2. 靶标视角核心查询（Tractability / 遗传约束 / 安全 / 交通灯 / 临床候选）

```graphql
query Target($id: String!, $diseaseId: String!) {
  target(ensemblId: $id) {
    id approvedSymbol approvedName biotype
    targetClass { id label }
    functionDescriptions
    tractability { modality label value }          # SM/AB/PR/OC 四模态逐项
    subcellularLocations { location source labelSL }
    geneticConstraint { constraintType exp score oe oeLower oeUpper }  # LOEUF 看 lof 行
    safetyLiabilities { datasource event effects { direction } literature url }
    prioritisation { items { key value } }          # 交通灯：hasPocket/hasSafetyEvent/mouseKOScore/表达特异性等
    mousePhenotypes { targetInModel modelPhenotypeId modelPhenotypeLabel modelPhenotypeClasses { label } }
    associatedDiseases(Bs: [$diseaseId]) {
      count rows { score novelty disease { id name }
        datasourceScores { id score } datatypeScores { id score } } }
    drugAndClinicalCandidates {
      count rows { id maxClinicalStage
        drug { id name drugType maximumClinicalStage }
        diseases { diseaseFromSource disease { id name } }
        clinicalReports { id title trialPhase trialOverallStatus year url } } }
  }
}
```
注意：`drugAndClinicalCandidates.count = 0` 很可能是**数据滞后**（ChEMBL 未收录新机制靶标的在研分子），不代表现实无临床项目——必须做 WebSearch 交叉验证。

## 3. 疾病视角（排名上下文）

```graphql
query Disease($diseaseId: String!) {
  disease(efoId: $diseaseId) {
    id name description
    therapeuticAreas { id name }
    associatedTargets { count rows { score novelty
      target { id approvedSymbol approvedName }
      datasourceScores { id score } } }
  }
}
```

## 4. 证据明细 + 遗传学 + 表达

```graphql
query TargetEvidence($id: String!, $diseaseId: String!) {
  target(ensemblId: $id) {
    evidences(efoIds: [$diseaseId]) {          # 注意这里参数名是 efoIds
      count rows { id datasourceId datatypeId score targetModulation
        directionOnTarget directionOnTrait targetRole literature
        publicationYear publicationFirstAuthor } }
    credibleSets {
      count rows { studyLocusId beta confidence pValueMantissa pValueExponent
        variant { id } study { id traitFromSource studyType }
        l2GPredictions { count rows { score target { id approvedSymbol } } } } }
    baselineExpression {
      count rows { tissueBiosample { biosampleId biosampleName }
        celltypeBiosample { biosampleId biosampleName }
        median specificity_score unit datasourceId } }
  }
}
```
- `literature` 字段是 PMID 或 PPR 号（预印本），用 europepmc_titles.py 补标题。
- credibleSets 大多是 cis-eQTL（trait 是转录本 ID 形式 `ENSG..._chr_start_end`），**不是疾病 GWAS**；L2G rows 空 = 无基因因果分配。

## 5. 靶标全部疾病关联（用于"跨适应症画像"与伪关联警示）

```graphql
query { target(ensemblId: $id) { associatedDiseases { count rows {
  score disease { id name } datasourceScores { id score } } } } }
```
解读：gwas_credible_sets 来源的关联可能是位点重叠伪关联；impc 来源是表型相似性映射，多为间接证据。

## 6. 数据版本

```graphql
query { meta { name dataPrefix dataVersion { month year iteration } } }
```
报告中标注 `dataPrefix`（如 platform2606 = 2026 年 6 月版）。

## 7. 辅助端点（非 OTP）

- Europe PMC 文献标题：`https://www.ebi.ac.uk/europepmc/webservices/rest/search?query=EXT_ID:<PMID>&resultType=core&format=json` → `resultList.result[0].title/.pubYear/.authorString`
- PDBe→PDB 映射：`https://www.ebi.ac.uk/pdbe/api/mappings/uniprot/<UniProtAC>`
- RCSB 条目详情：`https://data.rcsb.org/rest/v1/core/entry/<PDB_ID>`（`exptl.method`、`rcsb_accession_info.initial_release_date`、`struct.title` 含配体名、`rcsb_entry_info.nonpolymer_bound_components`）

## 8. 自检：introspection

```graphql
query { __schema { queryType { name } types { kind name fields { name args {
  name type { kind name ofType { kind name ofType { kind name ofType { kind name } } } } }
  type { kind name ofType { kind name ofType { kind name ofType { kind name } } } } } } } }
```
返回较大（约 130KB），建议落盘后用脚本解析目标类型字段，再构造查询。
