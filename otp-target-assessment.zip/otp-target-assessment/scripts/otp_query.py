#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
OTP 靶标-疾病评估：一键执行 Open Targets Platform GraphQL v4 查询。
输入靶标 Ensembl ID（或基因符号）与疾病 EFO/MONDO ID（或名称），
自动执行：search 解析 -> 靶标视角 -> 疾病视角 -> 证据明细 -> 遗传学 -> 表达 -> meta，
将结果 JSON 落盘，并打印精简摘要。

用法:
  python otp_query.py --target ENSG00000183695 --disease MONDO_0044212 [--outdir ./data]
  python otp_query.py --target MRGPRX2 --disease "chronic spontaneous urticaria"

依赖: 仅标准库 (urllib)。API 端点: https://api.platform.opentargets.org/api/v4/graphql
"""
import argparse, json, sys, time, urllib.request

API = "https://api.platform.opentargets.org/api/v4/graphql"

def gql(query, variables=None, retries=3):
    body = json.dumps({"query": query, "variables": variables or {}}).encode()
    req = urllib.request.Request(API, data=body, headers={"Content-Type": "application/json"})
    for i in range(retries):
        try:
            with urllib.request.urlopen(req, timeout=60) as r:
                return json.loads(r.read().decode())
        except Exception as e:
            if i == retries - 1:
                raise RuntimeError(f"GraphQL 请求失败: {e}")
            time.sleep(2 * (i + 1))

# ---------- 查询模板 ----------
Q_SEARCH = """
query Search($q: String!, $ent: [String!]) {
  search(queryString: $q, entityNames: $ent) { total hits { id entity name } }
}"""

Q_TARGET = """
query Target($id: String!, $diseaseId: String!) {
  target(ensemblId: $id) {
    id approvedSymbol approvedName biotype
    targetClass { id label }
    functionDescriptions
    tractability { modality label value }
    subcellularLocations { location source labelSL }
    geneticConstraint { constraintType exp score oe oeLower oeUpper }
    safetyLiabilities { datasource event effects { direction } literature url }
    prioritisation { items { key value } }
    mousePhenotypes { targetInModel modelPhenotypeId modelPhenotypeLabel modelPhenotypeClasses { label } }
    associatedDiseases(Bs: [$diseaseId]) {
      count rows { score novelty disease { id name } datasourceScores { id score } datatypeScores { id score } }
    }
    drugAndClinicalCandidates {
      count rows { id maxClinicalStage drug { id name drugType maximumClinicalStage }
        diseases { diseaseFromSource disease { id name } }
        clinicalReports { id title trialPhase trialOverallStatus year url } }
    }
  }
}"""

Q_DISEASE = """
query Disease($diseaseId: String!) {
  disease(efoId: $diseaseId) {
    id name description
    therapeuticAreas { id name }
    associatedTargets {
      count rows { score novelty target { id approvedSymbol approvedName }
        datasourceScores { id score } }
    }
  }
}"""

Q_EVIDENCE = """
query TargetEvidence($id: String!, $diseaseId: String!) {
  target(ensemblId: $id) {
    evidences(efoIds: [$diseaseId]) {
      count rows { id datasourceId datatypeId score targetModulation directionOnTarget
        directionOnTrait targetRole literature publicationYear publicationFirstAuthor }
    }
    credibleSets {
      count rows { studyLocusId beta confidence pValueMantissa pValueExponent
        variant { id } study { id traitFromSource studyType }
        l2GPredictions { count rows { score target { id approvedSymbol } } } }
    }
    baselineExpression {
      count rows { tissueBiosample { biosampleId biosampleName }
        celltypeBiosample { biosampleId biosampleName }
        median specificity_score unit datasourceId }
    }
  }
}"""

Q_ALL_DISEASES = """
query TargetAllDiseases($id: String!) {
  target(ensemblId: $id) {
    associatedDiseases { count rows { score disease { id name } datasourceScores { id score } } }
  }
}"""

Q_META = """query { meta { name dataPrefix dataVersion { month year iteration } } }"""

def resolve(query_strings):
    """返回 {query: [{id, entity, name}]}"""
    out = {}
    for q in query_strings:
        j = gql(Q_SEARCH, {"q": q, "ent": ["target", "disease"]})
        out[q] = j.get("data", {}).get("search", {}).get("hits", [])
    return out

def main():
    ap = argparse.ArgumentParser(description="OTP 靶标-疾病数据查询")
    ap.add_argument("--target", required=True, help="基因符号 或 Ensembl ID (ENSG...)")
    ap.add_argument("--disease", required=True, help="疾病名称 或 EFO/MONDO ID")
    ap.add_argument("--outdir", default="./otp_data", help="JSON 输出目录")
    args = ap.parse_args()

    target = args.target
    disease = args.disease
    if not target.startswith("ENSG"):
        res = resolve([target])
        hits = res.get(target, [])
        ens = [h for h in hits if h["entity"] == "target"]
        if not ens:
            sys.exit(f"无法解析靶标: {target}")
        target = ens[0]["id"]
        print(f"[resolve] 靶标 {target} -> {ens[0]['name']}")
    if not (disease.startswith("EFO_") or disease.startswith("MONDO_")):
        res = resolve([disease])
        hits = res.get(disease, [])
        dis = [h for h in hits if h["entity"] == "disease"]
        if not dis:
            sys.exit(f"无法解析疾病: {disease}")
        disease = dis[0]["id"]
        print(f"[resolve] 疾病 {disease} -> {dis[0]['name']}")

    import os
    os.makedirs(args.outdir, exist_ok=True)
    jobs = {
        "meta": (Q_META, {}),
        "target": (Q_TARGET, {"id": target, "diseaseId": disease}),
        "disease": (Q_DISEASE, {"diseaseId": disease}),
        "evidence": (Q_EVIDENCE, {"id": target, "diseaseId": disease}),
        "all_diseases": (Q_ALL_DISEASES, {"id": target}),
    }
    for name, (q, v) in jobs.items():
        j = gql(q, v)
        with open(os.path.join(args.outdir, f"{name}.json"), "w", encoding="utf-8") as f:
            json.dump(j, f, ensure_ascii=False, indent=1)
        if j.get("errors"):
            print(f"[{name}] ERRORS: {json.dumps(j['errors'])[:500]}")
        else:
            print(f"[{name}] OK")

    # ---- 精简摘要 ----
    t = json.load(open(os.path.join(args.outdir, "target.json"), encoding="utf-8"))["data"]["target"]
    d = json.load(open(os.path.join(args.outdir, "disease.json"), encoding="utf-8"))["data"]["disease"]
    ev = json.load(open(os.path.join(args.outdir, "evidence.json"), encoding="utf-8"))["data"]["target"]
    meta = json.load(open(os.path.join(args.outdir, "meta.json"), encoding="utf-8"))["data"]["meta"]

    print("\n=== 摘要 ===")
    print(f"数据版本: {meta.get('dataPrefix')} ({meta.get('dataVersion', {}).get('month')}/{meta.get('dataVersion', {}).get('year')})")
    print(f"靶标: {t.get('approvedSymbol')} ({t.get('id')}) | {t.get('approvedName')}")
    assoc = (t.get("associatedDiseases") or {}).get("rows") or []
    if assoc:
        a = assoc[0]
        print(f"关联分数 ({d.get('name')}): {a['score']:.4f} | 证据源: {[s['id'] for s in a.get('datasourceScores', [])]}")
    print(f"疾病侧靶标总数: {(d.get('associatedTargets') or {}).get('count')}")
    evs = (ev.get("evidences") or {}).get("rows") or []
    from collections import Counter
    src = Counter(e.get("datasourceId") for e in evs)
    typ = Counter(e.get("datatypeId") for e in evs)
    print(f"证据条数: {len(evs)} | 数据源构成: {dict(src)} | 类型构成: {dict(typ)}")
    print(f"临床候选: {(t.get('drugAndClinicalCandidates') or {}).get('count')} (OTP 口径, 注意数据滞后)")
    print(f"credible sets: {(ev.get('credibleSets') or {}).get('count')} (多为 cis-eQTL)")
    print("Tractability 临床先例:", {r["modality"]: [x["label"] for x in (t.get("tractability") or []) if x["label"].startswith("Approved") or x["label"].startswith("Advanced") or x["label"].startswith("Phase 1")] for r in []})

if __name__ == "__main__":
    main()
