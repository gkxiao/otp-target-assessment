#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
按 PMID（或 PPR 预印本号）批量获取文献标题/期刊/年份/第一作者，用于报告引用。

用法:
  python europepmc_titles.py 40122988 35853276 PPR973052

端点: https://www.ebi.ac.uk/europepmc/webservices/rest/search?query=EXT_ID:<id>&resultType=core&format=json
依赖: 仅标准库。
"""
import argparse, json, sys, time, urllib.request

def fetch(pmid):
    url = (f"https://www.ebi.ac.uk/europepmc/webservices/rest/search"
           f"?query=EXT_ID:{pmid}&resultType=core&format=json")
    req = urllib.request.Request(url, headers={"Accept": "application/json"})
    with urllib.request.urlopen(req, timeout=45) as r:
        j = json.loads(r.read().decode())
    row = (j.get("resultList") or {}).get("result") or [{}]
    row = row[0] or {}
    authors = (row.get("authorString") or "").split(",")[0]
    return {
        "id": pmid,
        "title": row.get("title", ""),
        "journal": ((row.get("journalInfo") or {}).get("journal") or {}).get("title", ""),
        "year": row.get("pubYear", ""),
        "first_author": authors,
    }

def main():
    ap = argparse.ArgumentParser(description="Europe PMC 文献标题查询")
    ap.add_argument("pmids", nargs="+", help="PMID 或 PPR 号")
    args = ap.parse_args()
    for p in args.pmids:
        try:
            r = fetch(p)
            print(f"{r['id']} | {r['title']} | {r['journal']} | {r['year']} | {r['first_author']}")
        except Exception as e:
            print(f"{p} | 查询失败: {e}", file=sys.stderr)
        time.sleep(0.2)

if __name__ == "__main__":
    main()
