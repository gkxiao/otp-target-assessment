#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
按 UniProt AC 列出靶标的全部 PDB 结构条目（方法 / 释放日期 / 配体 / 标题）。

用法:
  python rcsb_check.py --uniprot Q96LB1
  python rcsb_check.py --uniprot Q96LB1 --pdb 7VDH 7S8L   # 只看指定条目

说明:
  - RCSB Search API (POST): https://search.rcsb.org/rcsbsearch/v2/query
    按 UniProt AC 精确匹配 rcsb_polymer_entity_container_identifiers.reference_sequence_identifiers.database_accession
  - RCSB entry API:   https://data.rcsb.org/rest/v1/core/entry/<PDB_ID>
  - 表述纪律: Cryo-EM 结构不要称为"共晶"；区分激动剂/拮抗剂复合物。
依赖: 仅标准库。
"""
import argparse, json, sys, urllib.request

def post_json(url, payload, retries=3):
    data = json.dumps(payload).encode()
    req = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json", "Accept": "application/json"})
    for i in range(retries):
        try:
            with urllib.request.urlopen(req, timeout=45) as r:
                return json.loads(r.read().decode())
        except Exception as e:
            if i == retries - 1:
                raise RuntimeError(f"请求失败 {url}: {e}")

def get(url, retries=3):
    req = urllib.request.Request(url, headers={"Accept": "application/json"})
    for i in range(retries):
        try:
            with urllib.request.urlopen(req, timeout=45) as r:
                return json.loads(r.read().decode())
        except Exception as e:
            if i == retries - 1:
                raise RuntimeError(f"请求失败 {url}: {e}")

def list_pdb_ids(uniprot):
    payload = {
        "query": {
            "type": "terminal", "service": "text",
            "parameters": {
                "attribute": "rcsb_polymer_entity_container_identifiers.reference_sequence_identifiers.database_accession",
                "operator": "exact_match", "value": uniprot,
            },
        },
        "return_type": "entry",
    }
    j = post_json("https://search.rcsb.org/rcsbsearch/v2/query", payload)
    return sorted(r["identifier"] for r in j.get("result_set", []))

def entry_info(pdb):
    j = get(f"https://data.rcsb.org/rest/v1/core/entry/{pdb}")
    rel = (j.get("rcsb_accession_info") or {}).get("initial_release_date", "?")[:10]
    method = ", ".join(e.get("method", "?") for e in j.get("exptl", []) or [])
    title = ((j.get("struct") or {}).get("title") or "").strip()
    ligands = (j.get("rcsb_entry_info") or {}).get("nonpolymer_bound_components") or []
    return {"pdb": pdb, "release": rel, "method": method, "title": title, "ligands": ligands}

def main():
    ap = argparse.ArgumentParser(description="按 UniProt AC 列出 PDB 结构")
    ap.add_argument("--uniprot", required=True, help="UniProt AC, 如 Q96LB1")
    ap.add_argument("--pdb", nargs="*", help="只看指定 PDB ID")
    args = ap.parse_args()

    ids = args.pdb or list_pdb_ids(args.uniprot)
    if not ids:
        sys.exit(f"未找到 {args.uniprot} 的 PDB 条目")
    rows = []
    for p in ids:
        try:
            rows.append(entry_info(p))
        except Exception as e:
            print(f"{p}: {e}", file=sys.stderr)
    rows.sort(key=lambda r: r["release"])
    print(f"{'PDB':8} {'释放日期':12} {'方法':22} 配体/标题")
    for r in rows:
        lig = ",".join(r["ligands"]) if r["ligands"] else "—"
        print(f"{r['pdb']:8} {r['release']:12} {r['method'][:20]:22} {lig} | {r['title'][:60]}")

if __name__ == "__main__":
    main()
