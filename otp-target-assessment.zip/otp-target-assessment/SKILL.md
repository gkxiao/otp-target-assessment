---
name: otp-target-assessment
description: 基于 Open Targets Platform（OTP）的靶标-疾病成药可行性评估（target prioritisation / druggability assessment）。当用户要求评估某药物靶标（靶点/基因）在特定疾病上的开发前景——如关联分数、可成药性 Tractability、效应方向、安全性、临床先例、成功概率粗估——并希望输出结构化评估报告时使用。输入只需"靶标 + 疾病"（如"评估 MRGPRX2 在慢性自发性荨麻疹的开发前景"）。This skill should be used when the user asks to assess a drug target against a disease using Open Targets Platform data (association score, tractability, direction of effect, safety, clinical pipeline, probability estimate) and produce a structured report.
agent_created: true
---

# OTP 靶标-疾病成药可行性评估

## Overview

按统一流程评估"靶标 × 疾病"对的成药可行性，输出中文 HTML 评估报告。输入只需靶标（基因符号 / Ensembl ID / UniProt AC）与疾病（名称 / EFO / MONDO ID）。数据源：Open Targets Platform GraphQL API v4（实时查询）、RCSB/PDBe（结构核实）、Europe PMC（文献标题）、WebSearch（现实临床管线交叉验证）。

## 工作流程（严格按序执行）

### Step 1 解析实体 ID
- 用 OTP GraphQL `search` 解析靶标 Ensembl ID 与疾病 EFO/MONDO ID。
- 查询模板与参数陷阱见 `references/otp-queries.md`（§1）。
- 注意：CSU/慢性特发性荨麻疹常映射到 MONDO_0044212；同一疾病可能有多个同义节点，取命中中名称最匹配者。

### Step 2 拉取核心数据（推荐用脚本，避免手写查询）
- 运行 `scripts/otp_query.py --target <EnsemblID> --disease <EFO/MONDO ID> --outdir <目录>`，自动执行靶标视角、疾病视角、证据明细、遗传学、表达、meta 共 6 类查询并保存 JSON、打印精简摘要。
- 若脚本不可用或需定制字段，手工查询模板见 `references/otp-queries.md`（§2-§7），其中包含已验证的完整 GraphQL 查询。
- 必须采集的字段：tractability（四模态）、geneticConstraint、safetyLiabilities、prioritisation（交通灯）、mousePhenotypes、subcellularLocations、associatedDiseases(按疾病过滤) 的 datasourceScores/datatypeScores、drugAndClinicalCandidates、evidences（datasourceId/datatypeId/score/direction 字段）、credibleSets（含 L2G）、baselineExpression、disease 的 associatedTargets 排名。
- 数据版本：查 `meta { name dataPrefix dataVersion { month year iteration } }` 并在报告中标注。

### Step 3 证据富化
- 用 `scripts/europepmc_titles.py <PMID ...>` 获取 top 证据的文献标题与作者，用于报告引用。
- 检查 evidences 中 `directionOnTarget / directionOnTrait / targetModulation` 是否有值；若无值，方向判断需用功能证据 + 独立文献合成（见 `references/framework.md` §3）。

### Step 4 结构生物学核实（PDB）
- 运行 `scripts/rcsb_check.py --uniprot <UniProt AC>` 获取该靶标全部 PDB 条目（方法/释放日期/配体/标题）。
- 表述纪律：**不要用"共晶"描述 Cryo-EM 结构**；正确表述为"Cryo-EM 复合物结构（配体结合态）"。区分"激动剂结合态"与"拮抗剂/反向激动剂复合物"——公开 PDB 通常只有激动剂结构，拮抗剂复合物多未释放。
- 关联解读：口袋形状（浅/深、正构/变构）与 OTP"High-Quality Pocket"红灯的关系。

### Step 5 现实世界临床管线交叉验证
- 用 WebSearch 检索该靶标在目标疾病（及相关适应症）的临床在研项目：药物名、机制、阶段、关键数据、终止/反转事件。
- 重要认知：**OTP 的已知药物/临床候选字段存在明显数据滞后**（ChEMBL 未收录新机制靶标的在研分子时为空），必须以现实管线为准绳，并在报告中标注"OTP 记录 vs 现实世界"两个口径。
- 关注竞争格局与最近的口径反转（如公司撤回某适应症 Ⅱ 期计划），用一手信源（公司财报 PR、ClinicalTrials.gov）佐证。

### Step 6 五步法合成判断
按 `references/framework.md`（§1-§5）执行：
1. 关联分数解读（阈值 + "分数=证据丰度≠质量"修正）
2. 证据类型权重（遗传学 ×2 加成、已知药物、表达、动物模型、文献）
3. Tractability 模态匹配（小分子/抗体/PROTAC/其他 + 临床先例）
4. 效应方向核对（gain/loss-of-function × protect/risk → 激动剂/拮抗剂）
5. 安全性与交通灯叠加（FAERS、safety liabilities、小鼠 KO、基因约束）

### Step 7 概率粗估（做法 A）
按 `references/framework.md` §6：行业基线（Phase I→获批 ≈10%）+ 修正因子（遗传证据加成、临床概念验证、获批先例、毒理风险、竞争格局），输出示意性概率画像而非定量预测。

### Step 8 生成报告
- 用 `assets/report-skeleton.html` 作为骨架（含完整 CSS 与章节结构），填充数据后输出到工作区 `output/` 目录，文件命名 `{TARGET}_{DISEASE}_OTP评估报告.html`。
- 报告语言：简体中文；主题：跟随当前 IDE 主题（浅色主题用浅色背景/深色文字）。
- 章节结构（与骨架一致）：0 执行摘要（结论框+计分卡）→ 1-4 四大证据支柱 → 5 五步合成 → 6 概率 → 7 局限 → 8 下一步 → 9 附录（数据来源/文献/方法）。
- 关键认知框（必须出现）：分数≠质量、OTP 数据滞后、表达盲区（如 GTEx 不捕获肥大细胞等稀有细胞型）。
- 完成后调用 present_files 呈现报告。

## 核心纪律（从项目实战沉淀，务必遵守）

1. **区分"OTP 记录"与"现实世界"两个口径**：OTP 字段为空处标注"数据滞后"，并给出现实世界对照，避免把 OTP 空白误读为负面证据。
2. **分数 = 证据丰度，不是证据质量/成功概率**：高分≠能治病，低分≠靶标无效。罕见病/新疾病、文本挖掘权重低的数据源、以及表达图谱盲区都会压低分数。
3. **结构术语准确**：Cryo-EM ≠ 共晶；激动剂复合物 ≠ 拮抗剂复合物。
4. **效应方向优先于分数**：先判断"该开发抑制剂还是激动剂"，方向错误时成功率断崖式下降。
5. **毒理/安全是独立否决变量**：即使机制验证充分（如人体 PD 阳性），长期毒理失败（如 EP262 案例）可单独终止项目；报告中单列"毒理风险敞口"。
6. **所有外部结论可追溯**：报告附录列出 OTP 数据版本、查询日期、文献 PMID、管线信源与检索日期。
7. **概率部分是示意性粗估**：明确标注"非定量预测"，给出信息增量最强的观测节点。

## Resources

### scripts/
- `otp_query.py` — 一键执行全部 OTP GraphQL 查询（实体解析 + 6 类查询 + JSON 落盘 + 精简摘要）。用法：`python otp_query.py --target ENSG... --disease MONDO_... --outdir ./data`
- `europepmc_titles.py` — 按 PMID 批量获取文献标题/期刊/年份/作者。用法：`python europepmc_titles.py 40122988 35853276`
- `rcsb_check.py` — 按 UniProt AC 列出全部 PDB 条目（PDBe mapping + RCSB entry 详情：方法/释放日期/配体/标题）。用法：`python rcsb_check.py --uniprot Q96LB1`

### references/
- `otp-queries.md` — OTP GraphQL API 查询模板全集 + 参数陷阱（`Bs` 参数名、entityNames 用字符串、meta.dataVersion 需嵌套）+ europepmc/RCSB/PDBe 端点说明。
- `framework.md` — 五步合成法细则、概率粗估方法（做法 A/B）、报告章节规范、交通灯解读、项目实战教训清单。

### assets/
- `report-skeleton.html` — 中文评估报告 HTML 骨架（CSS + 章节结构 + 占位标记），生成报告时复制并填充。
